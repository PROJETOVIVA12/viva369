import React, { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useAcesso } from '@/contexts/AcessoContext';
import { Loader2 } from 'lucide-react';

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const { temAcesso, loading: acessoLoading, verificarAcesso } = useAcesso();
  const location = useLocation();

  // Verificar acesso quando usuário mudar
  useEffect(() => {
    if (user) {
      verificarAcesso();
    }
  }, [user]);

  // Se está carregando
  if (authLoading || acessoLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-emerald-400" />
          <p className="text-slate-400 text-sm">Verificando acesso...</p>
        </div>
      </div>
    );
  }

  // Se não tem usuário, redirecionar para login
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Se tem usuário mas não tem acesso, redirecionar para verificação
  if (!temAcesso) {
    return <Navigate to="/verificar-acesso" replace />;
  }

  // Se tem acesso, renderizar
  return <>{children}</>;
}
