import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';

interface AuthContextType {
  session: Session | null;
  user: User | null;
  loading: boolean;
  role: string | null;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  user: null,
  loading: true,
  role: null,
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchRole = async (userId: string) => {
    try {
      console.log('Buscando role para usuário:', userId);
      const { data, error } = await supabase
        .from('usuarios')
        .select('role')
        .eq('id', userId)
        .maybeSingle();

      if (!error && data) {
        console.log('Role encontrada:', data.role);
        setRole(data.role);
      } else {
        console.log('Nenhuma role encontrada, usando default');
        setRole('cliente');
      }
    } catch (error) {
      console.error('Erro ao buscar role:', error);
      setRole('cliente');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    console.log('AuthProvider - Inicializando...');
    
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('Sessão obtida:', session?.user?.email);
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchRole(session.user.id);
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      console.log('Auth state changed:', _event, session?.user?.email);
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchRole(session.user.id);
      } else {
        setRole(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ session, user, loading, role }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
// Adicionar no final do arquivo, antes do export
export const isAdmin = (user: User | null) => {
  if (!user) return false;
  return user.email === 'jocimarmachado1618@gmail.com';
};
