import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { 
  LayoutDashboard, Users, Gift, Trophy, Compass, Activity,
  Zap, Flame, Heart, Calendar, Target, 
  CheckCircle, Dumbbell, Coffee, Sparkle,
  ChevronRight, Rocket, Gem, Crown, Award, Brain
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

export default function UserDashboardPage() {
  const { user } = useAuth();
  const [stats] = useState({
    streak: 7,
    pontos: 450,
    nivel_saude: 'Ouro',
    dias_jornada: 23
  });

  const userName = user?.user_metadata?.nome || user?.email?.split('@')[0] || 'Usuário';
  const userInitial = userName.charAt(0).toUpperCase();

  return (
    <div className="space-y-6">
      {/* Header Premium com gradiente e brilho */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-amber-500 p-6 md:p-8 shadow-xl shadow-emerald-500/20">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 animate-pulse" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2 animate-pulse delay-100" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
        
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Avatar className="h-16 w-16 border-2 border-white/50 shadow-xl">
                <AvatarImage src={user?.user_metadata?.avatar_url} />
                <AvatarFallback className="bg-white/20 text-white text-xl backdrop-blur-sm font-bold">
                  {userInitial}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white animate-pulse" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-2">
                Bem-vindo, {userName}!
                <Crown className="h-5 w-5 text-amber-300 animate-pulse" />
              </h1>
              <p className="text-white/90 text-sm flex items-center gap-2">
                <Award className="h-4 w-4 text-amber-300" />
                <span className="font-medium">Nível {stats.nivel_saude}</span>
                <span className="w-1 h-1 rounded-full bg-white/50" />
                <Calendar className="h-3 w-3" />
                {stats.dias_jornada} dias na jornada
                <span className="w-1 h-1 rounded-full bg-white/50" />
                <Zap className="h-3 w-3 text-yellow-300" />
                {stats.pontos} pts
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge className="bg-white/20 text-white border-0 px-4 py-2 backdrop-blur-sm hover:bg-white/30 transition-all">
              <Flame className="h-4 w-4 mr-2 text-orange-300 animate-pulse" />
              Sequência: {stats.streak} dias
            </Badge>
            <Badge className="bg-white/20 text-white border-0 px-4 py-2 backdrop-blur-sm hover:bg-white/30 transition-all">
              <Zap className="h-4 w-4 mr-2 text-yellow-300" />
              {stats.pontos} pts
            </Badge>
          </div>
        </div>
      </div>

      {/* Menu Navegação com efeito glass */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
        {[
          { icon: LayoutDashboard, label: 'Dashboard', active: true },
          { icon: Users, label: 'Comunidade' },
          { icon: Gift, label: 'Indicações' },
          { icon: Trophy, label: 'Premiações' },
          { icon: Compass, label: 'Jornada' },
          { icon: Activity, label: 'Bioimpedância' },
        ].map((item, idx) => (
          <button
            key={idx}
            className={cn(
              "flex flex-col items-center gap-1 p-3 rounded-xl transition-all duration-300 group relative overflow-hidden",
              item.active 
                ? "bg-gradient-to-r from-emerald-500/30 to-amber-500/30 text-emerald-400 border border-emerald-500/30 shadow-lg shadow-emerald-500/10" 
                : "bg-slate-800/50 hover:bg-slate-700/50 text-slate-400 hover:text-white border border-slate-700/50 hover:border-slate-600"
            )}
          >
            <div className={cn(
              "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r from-emerald-500/5 to-amber-500/5"
            )} />
            <item.icon className={cn(
              "h-5 w-5 relative z-10 transition-transform group-hover:scale-110",
              item.active && "text-emerald-400"
            )} />
            <span className="text-xs font-medium relative z-10">{item.label}</span>
            {item.active && (
              <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-6 h-0.5 bg-gradient-to-r from-emerald-400 to-amber-400 rounded-full" />
            )}
          </button>
        ))}
      </div>

      {/* Cards de Métricas Premium */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: Flame, value: stats.streak, label: 'Sequência de Dias', gradient: 'from-orange-500 to-red-500', glow: 'shadow-orange-500/20' },
          { icon: Zap, value: stats.pontos, label: 'Pontuação VIVA+', gradient: 'from-yellow-500 to-amber-500', glow: 'shadow-yellow-500/20' },
          { icon: Heart, value: stats.nivel_saude, label: 'Nível de Saúde', gradient: 'from-green-500 to-emerald-500', glow: 'shadow-green-500/20' },
          { icon: Calendar, value: stats.dias_jornada, label: 'Dias na Jornada', gradient: 'from-blue-500 to-cyan-500', glow: 'shadow-blue-500/20' },
        ].map((item, idx) => (
          <Card key={idx} className={cn(
            "bg-slate-800/80 border-slate-700/50 transition-all duration-300 hover:scale-[1.02] hover:shadow-xl",
            `hover:${item.glow}`
          )}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={cn("p-2.5 rounded-xl bg-gradient-to-br", item.gradient, "text-white shadow-lg")}>
                  <item.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white tracking-tight">{item.value}</p>
                  <p className="text-xs text-slate-400 font-medium">{item.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Desafio Diário com destaque */}
      <Card className="bg-gradient-to-br from-slate-800 to-slate-800/80 border-emerald-500/30 border-2 relative overflow-hidden">
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-emerald-500/10 rounded-full blur-2xl" />
        <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-amber-500/10 rounded-full blur-2xl" />
        
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2 text-white">
                <div className="p-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-amber-500 text-white">
                  <Target className="h-4 w-4" />
                </div>
                Seu Próximo Desafio
              </CardTitle>
              <CardDescription className="text-slate-400">
                Complete o desafio de hoje para ganhar pontos!
              </CardDescription>
            </div>
            <Badge className="bg-gradient-to-r from-emerald-500 to-amber-500 text-white border-0 px-3 py-1.5 animate-pulse">
              +10 pts
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row md:items-center gap-4 p-4 bg-slate-900/30 rounded-xl border border-slate-700/50 backdrop-blur-sm">
            <div className="flex-1 flex items-center gap-3">
              <div className="p-3 rounded-full bg-gradient-to-r from-emerald-500/20 to-amber-500/20">
                <Dumbbell className="h-5 w-5 text-emerald-400" />
              </div>
              <div>
                <p className="font-semibold text-white">Complete 10 minutos de exercício</p>
                <p className="text-sm text-slate-400">Faça qualquer atividade física hoje</p>
              </div>
            </div>
            <Button className="gap-2 bg-gradient-to-r from-emerald-500 to-amber-500 hover:shadow-lg hover:shadow-emerald-500/30 text-white border-0 transition-all hover:scale-105">
              <CheckCircle className="h-4 w-4" />
              Marcar como feito
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Desafios da Semana */}
      <Card className="bg-slate-800/80 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2 text-white">
            <Sparkle className="h-5 w-5 text-yellow-500 animate-pulse" />
            Desafios da Semana
          </CardTitle>
          <CardDescription className="text-slate-400">
            Complete os desafios e acumule pontos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { id: 1, titulo: 'Beber 2L de água', pontos: 10, icon: Coffee },
              { id: 2, titulo: 'Caminhar 30 minutos', pontos: 15, icon: Dumbbell },
              { id: 3, titulo: 'Meditar 5 minutos', pontos: 10, icon: Brain },
              { id: 4, titulo: 'Comer uma fruta', pontos: 5, icon: Sparkle },
            ].map((desafio) => (
              <div 
                key={desafio.id}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-700/20 hover:bg-slate-700/40 border border-slate-700/50 transition-all hover:border-emerald-500/30 group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-1.5 rounded-lg bg-slate-700/50 text-slate-400 group-hover:bg-emerald-500/20 group-hover:text-emerald-400 transition-all">
                    <desafio.icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm text-white group-hover:text-emerald-400 transition-all">{desafio.titulo}</span>
                </div>
                <Badge variant="outline" className="text-xs border-emerald-500/30 text-emerald-400 bg-emerald-500/5">
                  +{desafio.pontos} pts
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-700/50 pt-4">
          <Button variant="ghost" className="w-full gap-2 text-slate-400 hover:text-white hover:bg-slate-700/50 group">
            Ver todos os desafios
            <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </CardFooter>
      </Card>

      {/* Progresso da Jornada */}
      <Card className="bg-slate-800/80 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2 text-white">
            <Rocket className="h-5 w-5 text-emerald-400" />
            Sua Jornada
          </CardTitle>
          <CardDescription className="text-slate-400">
            Você está no caminho certo!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-400">Progresso da Jornada</span>
                <span className="font-bold text-emerald-400">{Math.round((stats.dias_jornada / 30) * 100)}%</span>
              </div>
              <div className="relative h-3 bg-slate-700/50 rounded-full overflow-hidden">
                <div 
                  className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-emerald-400 to-amber-400 rounded-full"
                  style={{ width: `${(stats.dias_jornada / 30) * 100}%` }}
                />
              </div>
              <p className="text-xs text-slate-500 mt-2">
                {stats.dias_jornada} de 30 dias completos
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 hover:bg-blue-500/20 transition-all">
                <p className="text-sm font-medium text-blue-400 flex items-center gap-1">
                  <Rocket className="h-4 w-4" />
                  Próximo nível
                </p>
                <p className="text-xs text-blue-400/70">Faltam 7 dias para Prata</p>
              </div>
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/20 transition-all">
                <p className="text-sm font-medium text-emerald-400 flex items-center gap-1">
                  <Gem className="h-4 w-4" />
                  Meta da semana
                </p>
                <p className="text-xs text-emerald-400/70">Complete 5 desafios</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
