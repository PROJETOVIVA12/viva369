import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import {
  Calendar, CheckCircle, Circle, Clock, Flame,
  Leaf, Apple, Droplet, Moon, Sun, Zap,
  Award, Crown, Gem, Sparkles, Target,
  Users, Share2, Lock, Unlock, Star,
  BookOpen, Heart, Shield, Brain, Activity,
  AlertCircle, Info, Check, X, Coffee,
  Utensils, Droplets, Pill, Timer, TrendingUp
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { cn } from '@/lib/utils';

// ============================================
// ESTRUTURA DA LIMPEZA HEPÁTICA - 90 DIAS
// ============================================

const FASES_LIMPEZA = {
  preparacao: {
    nome: 'FASE 1 - PREPARAÇÃO',
    cor: 'from-emerald-500 to-green-500',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    text: 'text-emerald-400',
    icone: BookOpen,
    duracao: 'Dias 1-7',
    descricao: 'Preparação do corpo para a limpeza profunda',
    objetivos: [
      'Reduzir inflamações',
      'Preparar o fígado para a desintoxicação',
      'Iniciar alimentação leve'
    ]
  },
  limpeza1: {
    nome: 'FASE 2 - 1ª LIMPEZA',
    cor: 'from-amber-500 to-yellow-500',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    text: 'text-amber-400',
    icone: Droplet,
    duracao: 'Dias 8-15',
    descricao: 'Primeira limpeza hepática profunda',
    objetivos: [
      'Eliminar toxinas acumuladas',
      'Liberar cálculos biliares',
      'Restaurar função hepática'
    ]
  },
  recuperacao: {
    nome: 'FASE 3 - RECUPERAÇÃO',
    cor: 'from-blue-500 to-cyan-500',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
    text: 'text-blue-400',
    icone: Heart,
    duracao: 'Dias 16-30',
    descricao: 'Recuperação e fortalecimento do fígado',
    objetivos: [
      'Regenerar células hepáticas',
      'Fortalecer o sistema imunológico',
      'Estabelecer novos hábitos'
    ]
  },
  limpeza2: {
    nome: 'FASE 4 - 2ª LIMPEZA',
    cor: 'from-purple-500 to-violet-500',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/30',
    text: 'text-purple-400',
    icone: Shield,
    duracao: 'Dias 31-45',
    descricao: 'Segunda limpeza hepática - Consolidação',
    objetivos: [
      'Consolidar os resultados',
      'Limpeza mais profunda',
      'Equilíbrio hormonal'
    ]
  },
  fortalecimento: {
    nome: 'FASE 5 - FORTALECIMENTO',
    cor: 'from-orange-500 to-red-500',
    bg: 'bg-orange-500/10',
    border: 'border-orange-500/30',
    text: 'text-orange-400',
    icone: Shield,
    duracao: 'Dias 46-60',
    descricao: 'Fortalecimento e manutenção',
    objetivos: [
      'Manter os resultados',
      'Prevenir novas toxinas',
      'Estilo de vida saudável'
    ]
  },
  limpeza3: {
    nome: 'FASE 6 - 3ª LIMPEZA',
    cor: 'from-indigo-500 to-purple-500',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/30',
    text: 'text-indigo-400',
    icone: Target,
    duracao: 'Dias 61-75',
    descricao: 'Terceira limpeza - Consolidação final',
    objetivos: [
      'Limpeza definitiva',
      'Equilíbrio energético',
      'Saúde plena'
    ]
  },
  consolidacao: {
    nome: 'FASE 7 - CONSOLIDAÇÃO',
    cor: 'from-rose-500 to-pink-500',
    bg: 'bg-rose-500/10',
    border: 'border-rose-500/30',
    text: 'text-rose-400',
    icone: Crown,
    duracao: 'Dias 76-90',
    descricao: 'Consolidação da nova saúde',
    objetivos: [
      'Manter a saúde conquistada',
      'Prevenir recaídas',
      'Viver com vitalidade'
    ]
  }
};

export default function LimpezaHepaticaPage() {
  const { user } = useAuth();
  const [diasCompletos, setDiasCompletos] = useState(0);
  const [desafioAtivo, setDesafioAtivo] = useState(false);
  const [faseAtual, setFaseAtual] = useState('preparacao');

  const progressoTotal = Math.min((diasCompletos / 90) * 100, 100);

  const iniciarDesafio = () => {
    setDesafioAtivo(true);
    setDiasCompletos(0);
    setFaseAtual('preparacao');
  };

  const marcarDia = () => {
    if (diasCompletos < 90) {
      const novoDias = diasCompletos + 1;
      setDiasCompletos(novoDias);
      
      if (novoDias <= 7) setFaseAtual('preparacao');
      else if (novoDias <= 15) setFaseAtual('limpeza1');
      else if (novoDias <= 30) setFaseAtual('recuperacao');
      else if (novoDias <= 45) setFaseAtual('limpeza2');
      else if (novoDias <= 60) setFaseAtual('fortalecimento');
      else if (novoDias <= 75) setFaseAtual('limpeza3');
      else setFaseAtual('consolidacao');
    }
  };

  const getNivel = () => {
    if (diasCompletos >= 90) return { nome: 'Mestre da Saúde', icone: Crown, cor: 'text-amber-400' };
    if (diasCompletos >= 75) return { nome: 'Líder da Limpeza', icone: Shield, cor: 'text-purple-400' };
    if (diasCompletos >= 60) return { nome: 'Transformador', icone: Star, cor: 'text-blue-400' };
    if (diasCompletos >= 30) return { nome: 'Purificador', icone: Target, cor: 'text-emerald-400' };
    if (diasCompletos >= 7) return { nome: 'Iniciante', icone: BookOpen, cor: 'text-slate-400' };
    return { nome: 'Desafiante', icone: Circle, cor: 'text-slate-500' };
  };

  const nivel = getNivel();
  const fase = FASES_LIMPEZA[faseAtual as keyof typeof FASES_LIMPEZA];
  const Icon = fase?.icone || BookOpen;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600 via-amber-500 to-purple-500 p-6">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Sparkles className="h-6 w-6" />
              Limpeza Hepática - 90 Dias
            </h1>
            <p className="text-white/80 text-sm">Protocolo completo de limpeza e desintoxicação</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Badge className="bg-white/20 text-white border-0 px-4 py-2">
              <Target className="h-4 w-4 mr-2" />
              {diasCompletos} / 90 dias
            </Badge>
            <Badge className={cn("bg-white/20 text-white border-0 px-4 py-2", nivel.cor)}>
              <nivel.icone className="h-4 w-4 mr-2" />
              {nivel.nome}
            </Badge>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-sm text-white/70 mb-1">
            <span>Início</span>
            <span>{Math.round(progressoTotal)}%</span>
            <span>90 Dias</span>
          </div>
          <Progress value={progressoTotal} className="h-2 bg-white/20" />
        </div>
      </div>

      {/* Botões */}
      <div className="flex flex-wrap gap-3">
        {!desafioAtivo ? (
          <Button className="bg-gradient-to-r from-emerald-500 to-amber-500 text-white" onClick={iniciarDesafio}>
            <Unlock className="h-4 w-4 mr-2" />
            Iniciar Desafio de 90 Dias
          </Button>
        ) : (
          <Button className="bg-emerald-500 hover:bg-emerald-600 text-white" onClick={marcarDia}>
            <CheckCircle className="h-4 w-4 mr-2" />
            Marcar Dia Completo
          </Button>
        )}
        <Button variant="outline" className="border-slate-600 text-slate-400 hover:text-white">
          <Share2 className="h-4 w-4 mr-2" />
          Convidar Amigo
        </Button>
        <Button variant="outline" className="border-slate-600 text-slate-400 hover:text-white">
          <Users className="h-4 w-4 mr-2" />
          Criar Grupo
        </Button>
      </div>

      {/* Aviso Médico */}
      <Alert className="bg-amber-500/10 border-amber-500/30">
        <AlertCircle className="h-4 w-4 text-amber-400" />
        <AlertTitle className="text-amber-400">⚠️ Atenção à Saúde</AlertTitle>
        <AlertDescription className="text-slate-300 text-sm">
          O VIVA369 é uma plataforma de incentivo à saúde. Consulte sempre um profissional de saúde 
          antes de iniciar qualquer programa. Informe seu médico sobre condições como diabetes, 
          hipertensão, alergias ou qualquer outra condição de saúde.
        </AlertDescription>
      </Alert>

      {/* Fase Atual */}
      {desafioAtivo && fase && (
        <Card className={cn("border-2", fase.border, fase.bg)}>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className={cn("p-3 rounded-xl bg-gradient-to-r", fase.cor, "text-white")}>
                <Icon className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className={cn("text-xl", fase.text)}>{fase.nome}</CardTitle>
                <CardDescription className="text-slate-400">{fase.descricao}</CardDescription>
              </div>
              <Badge className={cn("ml-auto", fase.border, fase.text)}>
                {fase.duracao}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-sm text-slate-300 font-medium">🎯 Objetivos:</p>
              <ul className="list-disc list-inside text-sm text-slate-400 space-y-1">
                {fase.objetivos.map((obj: string, idx: number) => (
                  <li key={idx}>{obj}</li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Conteúdo */}
      <Tabs defaultValue="info" className="w-full">
        <TabsList className="grid grid-cols-3 bg-slate-800 p-1 rounded-xl">
          <TabsTrigger value="info" className="data-[state=active]:bg-emerald-500/20 data-[state=active]:text-emerald-400">
            <BookOpen className="h-4 w-4 mr-2" />
            Informações
          </TabsTrigger>
          <TabsTrigger value="alimentacao" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">
            <Utensils className="h-4 w-4 mr-2" />
            Alimentação
          </TabsTrigger>
          <TabsTrigger value="progresso" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
            <TrendingUp className="h-4 w-4 mr-2" />
            Progresso
          </TabsTrigger>
        </TabsList>

        <TabsContent value="info" className="mt-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Sobre a Limpeza Hepática</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <p>
                A limpeza hepática é um processo natural de desintoxicação do fígado, 
                que ajuda a eliminar toxinas acumuladas e melhorar a saúde geral.
              </p>
              <div className="bg-slate-700/30 p-4 rounded-lg">
                <h4 className="text-emerald-400 font-medium mb-2">📋 O que você vai aprender:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Como preparar seu corpo para a limpeza</li>
                  <li>Alimentos que auxiliam na desintoxicação</li>
                  <li>Protocolo completo de 90 dias</li>
                  <li>Como manter os resultados</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alimentacao" className="mt-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Alimentação Recomendada</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="text-emerald-400 font-medium">✅ Alimentos Permitidos</h4>
                  <ul className="space-y-1 text-sm text-slate-300">
                    <li>• Maçãs orgânicas</li>
                    <li>• Vegetais crus e cozidos</li>
                    <li>• Grãos integrais</li>
                    <li>• Azeite de oliva extra virgem</li>
                    <li>• Sucos naturais</li>
                    <li>• Chás de ervas</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="text-red-400 font-medium">❌ Alimentos Evitar</h4>
                  <ul className="space-y-1 text-sm text-slate-300">
                    <li>• Açúcar refinado</li>
                    <li>• Alimentos processados</li>
                    <li>• Frituras e gorduras ruins</li>
                    <li>• Álcool</li>
                    <li>• Cafeína</li>
                    <li>• Laticínios</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progresso" className="mt-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Seu Progresso</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Dias Completos</span>
                    <span className="text-emerald-400">{diasCompletos}/90</span>
                  </div>
                  <Progress value={progressoTotal} className="h-3 bg-slate-700" />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-3 bg-slate-700/30 rounded-lg">
                    <div className="text-2xl">🌿</div>
                    <p className="text-xs text-slate-400">Preparação</p>
                  </div>
                  <div className="text-center p-3 bg-slate-700/30 rounded-lg">
                    <div className="text-2xl">💧</div>
                    <p className="text-xs text-slate-400">Limpeza</p>
                  </div>
                  <div className="text-center p-3 bg-slate-700/30 rounded-lg">
                    <div className="text-2xl">💪</div>
                    <p className="text-xs text-slate-400">Manutenção</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
