import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Loader2, Plus, TrendingUp, TrendingDown, Activity, 
  Scale, Ruler, Droplet, Heart, Zap, Target, 
  Calendar, ChevronDown, ChevronUp, LineChart,
  Download, Share2, Trash2, Edit, Eye
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface AvaliacaoBioimpedancia {
  id: string;
  user_id: string;
  data_avaliacao: string;
  peso: number;
  altura: number;
  percentual_gordura: number;
  massa_muscular: number;
  massa_gordura: number;
  agua_corporal: number;
  metabolismo_basal: number;
  imc: number;
  idade_metabolica: number;
  percentual_osso: number;
  viscerais: number;
  observacoes?: string;
  created_at: string;
}

interface Evolucao {
  data: string;
  peso: number;
  gordura: number;
  massa_muscular: number;
  imc: number;
}

export default function BioimpedanciaPage() {
  const { user } = useAuth();
  const [avaliacoes, setAvaliacoes] = useState<AvaliacaoBioimpedancia[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editando, setEditando] = useState<AvaliacaoBioimpedancia | null>(null);
  const [formData, setFormData] = useState({
    data_avaliacao: new Date().toISOString().split('T')[0],
    peso: '',
    altura: '',
    percentual_gordura: '',
    massa_muscular: '',
    massa_gordura: '',
    agua_corporal: '',
    metabolismo_basal: '',
    imc: '',
    idade_metabolica: '',
    percentual_osso: '',
    viscerais: '',
    observacoes: '',
  });
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [evolucao, setEvolucao] = useState<Evolucao[]>([]);

  useEffect(() => {
    if (user) {
      carregarAvaliacoes();
    }
  }, [user]);

  const carregarAvaliacoes = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('bioimpedancia')
        .select('*')
        .eq('user_id', user.id)
        .order('data_avaliacao', { ascending: false });

      if (error) throw error;
      setAvaliacoes(data || []);
      
      // Calcular evolução
      if (data && data.length > 0) {
        const evolucaoData = data.map(av => ({
          data: format(new Date(av.data_avaliacao), 'dd/MM/yyyy'),
          peso: av.peso,
          gordura: av.percentual_gordura,
          massa_muscular: av.massa_muscular,
          imc: av.imc,
        })).reverse();
        setEvolucao(evolucaoData);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const calcularMetadados = (peso: number, altura: number, gordura: number, massa_muscular: number) => {
    const imc = peso / ((altura / 100) ** 2);
    const massa_gordura = (peso * gordura) / 100;
    const agua_corporal = (peso - massa_gordura - massa_muscular) * 0.7;
    const metabolismo_basal = (10 * peso) + (6.25 * altura) - (5 * 30) + 5;
    const percentual_osso = (peso * 0.15) * 100 / peso;
    const idade_metabolica = 30 + (gordura - 20) * 0.5;
    const viscerais = Math.round(gordura / 3);

    return { imc, massa_gordura, agua_corporal, metabolismo_basal, percentual_osso, idade_metabolica, viscerais };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    try {
      const peso = parseFloat(formData.peso);
      const altura = parseFloat(formData.altura);
      const gordura = parseFloat(formData.percentual_gordura);
      const massa_muscular = parseFloat(formData.massa_muscular);

      if (!peso || !altura || !gordura || !massa_muscular) {
        setError('Preencha todos os campos obrigatórios');
        return;
      }

      const metadados = calcularMetadados(peso, altura, gordura, massa_muscular);

      const dadosParaSalvar = {
        user_id: user?.id,
        data_avaliacao: formData.data_avaliacao,
        peso,
        altura,
        percentual_gordura: gordura,
        massa_muscular,
        massa_gordura: metadados.massa_gordura,
        agua_corporal: metadados.agua_corporal,
        metabolismo_basal: metadados.metabolismo_basal,
        imc: metadados.imc,
        idade_metabolica: metadados.idade_metabolica,
        percentual_osso: metadados.percentual_osso,
        viscerais: metadados.viscerais,
        observacoes: formData.observacoes,
      };

      let result;
      if (editando) {
        result = await supabase
          .from('bioimpedancia')
          .update(dadosParaSalvar)
          .eq('id', editando.id);
      } else {
        result = await supabase
          .from('bioimpedancia')
          .insert([dadosParaSalvar]);
      }

      if (result.error) throw result.error;

      setSuccess(true);
      setDialogOpen(false);
      setEditando(null);
      resetForm();
      carregarAvaliacoes();

      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const resetForm = () => {
    setFormData({
      data_avaliacao: new Date().toISOString().split('T')[0],
      peso: '',
      altura: '',
      percentual_gordura: '',
      massa_muscular: '',
      massa_gordura: '',
      agua_corporal: '',
      metabolismo_basal: '',
      imc: '',
      idade_metabolica: '',
      percentual_osso: '',
      viscerais: '',
      observacoes: '',
    });
  };

  const handleEdit = (avaliacao: AvaliacaoBioimpedancia) => {
    setEditando(avaliacao);
    setFormData({
      data_avaliacao: avaliacao.data_avaliacao.split('T')[0],
      peso: avaliacao.peso.toString(),
      altura: avaliacao.altura.toString(),
      percentual_gordura: avaliacao.percentual_gordura.toString(),
      massa_muscular: avaliacao.massa_muscular.toString(),
      massa_gordura: avaliacao.massa_gordura?.toString() || '',
      agua_corporal: avaliacao.agua_corporal?.toString() || '',
      metabolismo_basal: avaliacao.metabolismo_basal?.toString() || '',
      imc: avaliacao.imc?.toString() || '',
      idade_metabolica: avaliacao.idade_metabolica?.toString() || '',
      percentual_osso: avaliacao.percentual_osso?.toString() || '',
      viscerais: avaliacao.viscerais?.toString() || '',
      observacoes: avaliacao.observacoes || '',
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir esta avaliação?')) return;
    try {
      const { error } = await supabase
        .from('bioimpedancia')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      carregarAvaliacoes();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const getUltimaAvaliacao = () => {
    if (avaliacoes.length === 0) return null;
    return avaliacoes[0];
  };

  const getEvolucao = (campo: keyof AvaliacaoBioimpedancia) => {
    if (avaliacoes.length < 2) return null;
    const primeiro = avaliacoes[avaliacoes.length - 1][campo] as number;
    const ultimo = avaliacoes[0][campo] as number;
    return {
      valor: ultimo - primeiro,
      percentual: ((ultimo - primeiro) / primeiro) * 100,
    };
  };

  const renderMetricCard = (label: string, value: number | string, unit: string, icon: React.ReactNode, evolucao?: { valor: number; percentual: number } | null) => {
    const isPositive = evolucao && evolucao.valor > 0;
    const isNegative = evolucao && evolucao.valor < 0;
    const isNeutral = evolucao && evolucao.valor === 0;

    return (
      <Card className="relative overflow-hidden">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {icon}
              <CardDescription>{label}</CardDescription>
            </div>
            {evolucao && (
              <Badge variant={isPositive ? "destructive" : isNegative ? "default" : "secondary"} className="text-xs">
                {isPositive && <TrendingUp className="h-3 w-3 mr-1" />}
                {isNegative && <TrendingDown className="h-3 w-3 mr-1" />}
                {isNeutral && "→"}
                {evolucao.percentual.toFixed(1)}%
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold">{typeof value === 'number' ? value.toFixed(1) : value}</span>
            <span className="text-sm text-muted-foreground">{unit}</span>
          </div>
        </CardContent>
      </Card>
    );
  };

  const ultima = getUltimaAvaliacao();
  const evolucaoPeso = getEvolucao('peso');
  const evolucaoGordura = getEvolucao('percentual_gordura');
  const evolucaoMuscular = getEvolucao('massa_muscular');
  const evolucaoIMC = getEvolucao('imc');

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Bioimpedância</h1>
          <p className="text-muted-foreground">
            Acompanhe sua evolução corporal — Antes × Depois.
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Avaliação
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editando ? 'Editar Avaliação' : 'Registrar Nova Avaliação'}</DialogTitle>
              <DialogDescription>
                Insira os dados da sua bioimpedância mais recente.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                {success && (
                  <Alert className="bg-green-50 text-green-800 border-green-200">
                    <AlertDescription>Avaliação salva com sucesso!</AlertDescription>
                  </Alert>
                )}

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="data_avaliacao">Data da Avaliação</Label>
                    <Input
                      id="data_avaliacao"
                      type="date"
                      value={formData.data_avaliacao}
                      onChange={(e) => setFormData({ ...formData, data_avaliacao: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="peso">Peso (kg)</Label>
                    <Input
                      id="peso"
                      type="number"
                      step="0.1"
                      placeholder="Ex: 75.5"
                      value={formData.peso}
                      onChange={(e) => setFormData({ ...formData, peso: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="altura">Altura (cm)</Label>
                    <Input
                      id="altura"
                      type="number"
                      step="0.1"
                      placeholder="Ex: 170"
                      value={formData.altura}
                      onChange={(e) => setFormData({ ...formData, altura: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="percentual_gordura">% Gordura Corporal</Label>
                    <Input
                      id="percentual_gordura"
                      type="number"
                      step="0.1"
                      placeholder="Ex: 25.3"
                      value={formData.percentual_gordura}
                      onChange={(e) => setFormData({ ...formData, percentual_gordura: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="massa_muscular">Massa Muscular (kg)</Label>
                    <Input
                      id="massa_muscular"
                      type="number"
                      step="0.1"
                      placeholder="Ex: 35.2"
                      value={formData.massa_muscular}
                      onChange={(e) => setFormData({ ...formData, massa_muscular: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="massa_gordura">Massa Gorda (kg) - Calculado</Label>
                    <Input
                      id="massa_gordura"
                      type="number"
                      step="0.1"
                      placeholder="Calculado automaticamente"
                      value={formData.massa_gordura}
                      disabled
                      className="bg-muted"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="agua_corporal">Água Corporal (kg) - Calculado</Label>
                    <Input
                      id="agua_corporal"
                      type="number"
                      step="0.1"
                      placeholder="Calculado automaticamente"
                      value={formData.agua_corporal}
                      disabled
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <Label htmlFor="metabolismo_basal">Metabolismo Basal - Calculado</Label>
                    <Input
                      id="metabolismo_basal"
                      type="number"
                      step="0.1"
                      placeholder="Calculado automaticamente"
                      value={formData.metabolismo_basal}
                      disabled
                      className="bg-muted"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="imc">IMC - Calculado</Label>
                    <Input
                      id="imc"
                      type="number"
                      step="0.1"
                      placeholder="Calculado automaticamente"
                      value={formData.imc}
                      disabled
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <Label htmlFor="idade_metabolica">Idade Metabólica - Calculado</Label>
                    <Input
                      id="idade_metabolica"
                      type="number"
                      placeholder="Calculado automaticamente"
                      value={formData.idade_metabolica}
                      disabled
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <Label htmlFor="viscerais">Gordura Visceral - Calculado</Label>
                    <Input
                      id="viscerais"
                      type="number"
                      placeholder="Calculado automaticamente"
                      value={formData.viscerais}
                      disabled
                      className="bg-muted"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea
                    id="observacoes"
                    placeholder="Como você está se sentindo? Mudanças percebidas..."
                    value={formData.observacoes}
                    onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); setEditando(null); resetForm(); }}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editando ? 'Atualizar Avaliação' : 'Salvar Avaliação'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Métricas Principais - Última Avaliação */}
      {ultima && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {renderMetricCard(
            'Peso',
            ultima.peso,
            'kg',
            <Scale className="h-4 w-4 text-blue-500" />,
            evolucaoPeso
          )}
          {renderMetricCard(
            'Gordura',
            ultima.percentual_gordura,
            '%',
            <Droplet className="h-4 w-4 text-orange-500" />,
            evolucaoGordura
          )}
          {renderMetricCard(
            'Massa Muscular',
            ultima.massa_muscular,
            'kg',
            <Activity className="h-4 w-4 text-green-500" />,
            evolucaoMuscular
          )}
          {renderMetricCard(
            'IMC',
            ultima.imc,
            '',
            <Target className="h-4 w-4 text-purple-500" />,
            evolucaoIMC
          )}
        </div>
      )}

      {/* Gráfico de Evolução Simplificado */}
      {evolucao.length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Evolução</CardTitle>
            <CardDescription>Acompanhe sua progressão ao longo do tempo</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Peso</span>
                  <span className="text-muted-foreground">
                    {evolucao[0].peso}kg → {evolucao[evolucao.length - 1].peso}kg
                  </span>
                </div>
                <Progress 
                  value={((evolucao[0].peso - Math.min(...evolucao.map(e => e.peso))) / (Math.max(...evolucao.map(e => e.peso)) - Math.min(...evolucao.map(e => e.peso)))) * 100} 
                  className="h-2"
                />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>% Gordura</span>
                  <span className="text-muted-foreground">
                    {evolucao[0].gordura}% → {evolucao[evolucao.length - 1].gordura}%
                  </span>
                </div>
                <Progress 
                  value={((Math.max(...evolucao.map(e => e.gordura)) - evolucao[0].gordura) / (Math.max(...evolucao.map(e => e.gordura)) - Math.min(...evolucao.map(e => e.gordura)))) * 100} 
                  className="h-2"
                />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Massa Muscular</span>
                  <span className="text-muted-foreground">
                    {evolucao[0].massa_muscular}kg → {evolucao[evolucao.length - 1].massa_muscular}kg
                  </span>
                </div>
                <Progress 
                  value={((evolucao[0].massa_muscular - Math.min(...evolucao.map(e => e.massa_muscular))) / (Math.max(...evolucao.map(e => e.massa_muscular)) - Math.min(...evolucao.map(e => e.massa_muscular)))) * 100} 
                  className="h-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Histórico de Avaliações */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center justify-between">
            <span>Histórico de Avaliações</span>
            <Badge variant="secondary">{avaliacoes.length} registros</Badge>
          </CardTitle>
          <CardDescription>
            Todas as suas avaliações de bioimpedância registradas
          </CardDescription>
        </CardHeader>
        <CardContent>
          {avaliacoes.length === 0 ? (
            <div className="text-center py-12">
              <Scale className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">Nenhuma avaliação registrada.</p>
              <p className="text-sm text-muted-foreground/70">
                Clique em "Nova Avaliação" para começar.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {avaliacoes.map((avaliacao, index) => (
                <div key={avaliacao.id} className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="space-y-2 md:space-y-0 md:flex md:items-center md:gap-6">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">
                        {format(new Date(avaliacao.data_avaliacao), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                      </span>
                      {index === 0 && (
                        <Badge className="bg-primary/10 text-primary border-primary/20">Mais Recente</Badge>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm">
                      <span><span className="text-muted-foreground">Peso:</span> {avaliacao.peso}kg</span>
                      <span><span className="text-muted-foreground">Gordura:</span> {avaliacao.percentual_gordura}%</span>
                      <span><span className="text-muted-foreground">M. Muscular:</span> {avaliacao.massa_muscular}kg</span>
                      <span><span className="text-muted-foreground">IMC:</span> {avaliacao.imc.toFixed(1)}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-2 md:mt-0">
                    <Button variant="ghost" size="sm" onClick={() => handleEdit(avaliacao)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(avaliacao.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dicas e Recomendações */}
      {ultima && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-500" />
              Recomendações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              {ultima.percentual_gordura > 25 && (
                <div className="p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
                  <p className="text-sm font-medium text-orange-800 dark:text-orange-300">
                    ⚠️ Gordura elevada
                  </p>
                  <p className="text-xs text-orange-600 dark:text-orange-400">
                    Considere aumentar atividades aeróbicas e revisar alimentação.
                  </p>
                </div>
              )}
              {ultima.massa_muscular < 30 && (
                <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="text-sm font-medium text-blue-800 dark:text-blue-300">
                    💪 Fortalecimento muscular
                  </p>
                  <p className="text-xs text-blue-600 dark:text-blue-400">
                    Invista em treino de força para aumentar massa muscular.
                  </p>
                </div>
              )}
              {ultima.imc > 25 && (
                <div className="p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                  <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">
                    📊 IMC acima do ideal
                  </p>
                  <p className="text-xs text-yellow-600 dark:text-yellow-400">
                    Busque equilíbrio entre dieta e exercícios.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
