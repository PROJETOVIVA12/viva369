import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, UserPlus, Gift, Users } from 'lucide-react';
import { TermoConsentimento } from '@/components/TermoConsentimento';

const schema = z.object({
  nome: z.string().min(3, 'Nome deve ter pelo menos 3 caracteres'),
  email: z.string().email('Email inválido'),
  senha: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
  telefone: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function RegistrarPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [showTermo, setShowTermo] = useState(false);
  const [formData, setFormData] = useState<FormData | null>(null);
  const [codigoRef, setCodigoRef] = useState<string | null>(null);
  const [nomeIndicador, setNomeIndicador] = useState<string>('');

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  // Verificar código de indicação na URL
  useEffect(() => {
    const ref = searchParams.get('ref');
    if (ref) {
      setCodigoRef(ref);
      // Buscar nome do indicador
      buscarNomeIndicador(ref);
    }
  }, [searchParams]);

  const buscarNomeIndicador = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('usuarios')
        .select('nome')
        .eq('id', userId)
        .single();

      if (data) {
        setNomeIndicador(data.nome || 'Usuário');
      }
    } catch (error) {
      console.error('Erro ao buscar indicador:', error);
    }
  };

  const onSubmit = async (data: FormData) => {
    setFormData(data);
    setShowTermo(true);
  };

  const handleTermoAccept = async () => {
    if (!formData) return;
    
    setError(null);
    try {
      const { data: authData, error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.senha,
        options: {
          data: {
            nome: formData.nome,
            telefone: formData.telefone || '',
            role: 'cliente',
            termo_aceito: true,
            data_termo: new Date().toISOString(),
            indicado_por: codigoRef,
          },
        },
      });

      if (error) throw error;

      // Se tiver código de indicação, atualizar o perfil
      if (codigoRef && authData.user) {
        await supabase
          .from('perfis')
          .update({ 
            codigo_indicacao: authData.user.id,
            lider_id: codigoRef
          })
          .eq('id', authData.user.id);
      }

      setSuccess(true);
      setTimeout(() => navigate('/login'), 3000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-secondary/10 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <UserPlus className="h-6 w-6 text-emerald-400" />
            Criar Conta VIVA369
          </CardTitle>
          <CardDescription>
            {codigoRef ? (
              <span className="text-emerald-400 flex items-center gap-2">
                <Gift className="h-4 w-4" />
                Convidado por: <strong>{nomeIndicador || 'Usuário'}</strong>
              </span>
            ) : (
              'Preencha os dados para iniciar sua jornada de saúde'
            )}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {success && (
            <Alert className="mb-4 bg-green-50 text-green-800 border-green-200">
              <AlertDescription>
                Cadastro realizado com sucesso! Redirecionando para o login...
              </AlertDescription>
            </Alert>
          )}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="nome">Nome</Label>
              <Input id="nome" {...register('nome')} />
              {errors.nome && <p className="text-sm text-red-500 mt-1">{errors.nome.message}</p>}
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" {...register('email')} />
              {errors.email && <p className="text-sm text-red-500 mt-1">{errors.email.message}</p>}
            </div>
            <div>
              <Label htmlFor="senha">Senha</Label>
              <Input id="senha" type="password" {...register('senha')} />
              {errors.senha && <p className="text-sm text-red-500 mt-1">{errors.senha.message}</p>}
            </div>
            <div>
              <Label htmlFor="telefone">Telefone (opcional)</Label>
              <Input id="telefone" {...register('telefone')} />
            </div>

            {codigoRef && (
              <div className="bg-emerald-500/10 p-3 rounded-lg border border-emerald-500/20">
                <p className="text-sm text-emerald-400 flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Você está sendo indicado por <strong>{nomeIndicador || 'um amigo'}</strong>
                </p>
                <p className="text-xs text-emerald-400/70 mt-1">
                  ID do Indicador: {codigoRef.substring(0, 8)}...
                </p>
              </div>
            )}

            <Button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-amber-500 text-white" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Cadastrar'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          <p className="text-sm text-muted-foreground">
            Já tem uma conta?{' '}
            <Link to="/login" className="text-emerald-400 hover:underline">
              Faça login
            </Link>
          </p>
          <p className="text-xs text-slate-500 text-center">
            Ao se cadastrar, você concorda com os Termos de Uso e Política de Privacidade
          </p>
        </CardFooter>
      </Card>

      <TermoConsentimento 
        open={showTermo}
        onOpenChange={setShowTermo}
        onAccept={handleTermoAccept}
      />
    </div>
  );
}
