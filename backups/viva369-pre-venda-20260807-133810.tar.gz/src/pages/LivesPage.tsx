import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Video, Calendar, Bell, Play, Clock, Users, ExternalLink } from 'lucide-react';

interface Live {
  id: string;
  titulo: string;
  descricao: string;
  data: string;
  hora: string;
  duracao: string;
  link: string;
  status: 'ao_vivo' | 'proxima' | 'gravada';
  espectadores?: number;
  host: string;
  categoria: string;
}

const LIVES: Live[] = [
  {
    id: '1',
    titulo: 'Nutrição Funcional para Iniciantes',
    descricao: 'Aprenda os fundamentos da alimentação saudável e como montar seu prato ideal.',
    data: '2026-08-05',
    hora: '20:00',
    duracao: '1h30',
    link: 'https://wa.me/5571999369369',
    status: 'proxima',
    host: 'Dr. Carlos Nutricionista',
    categoria: 'Nutrição',
  },
  {
    id: '2',
    titulo: 'Treino HIIT para Casa — Sem equipamento',
    descricao: 'Circuito de alta intensidade que você pode fazer em qualquer lugar.',
    data: '2026-08-07',
    hora: '19:00',
    duracao: '45min',
    link: 'https://wa.me/5571999369369',
    status: 'proxima',
    host: 'Coach Ana Fitness',
    categoria: 'Movimento',
  },
  {
    id: '3',
    titulo: 'Meditação Guiada — Redução do Estresse',
    descricao: 'Sessão de meditação para relaxar mente e corpo após a semana intensa.',
    data: '2026-08-09',
    hora: '10:00',
    duracao: '30min',
    link: 'https://wa.me/5571999369369',
    status: 'proxima',
    host: 'Mestre João Bem-Estar',
    categoria: 'Mentalidade',
  },
  {
    id: '4',
    titulo: 'Hidratação e Performance — Mitos e Verdades',
    descricao: 'Descubra a quantidade ideal de água para seu biotipo e estilo de vida.',
    data: '2026-07-28',
    hora: '20:00',
    duracao: '1h',
    link: '#',
    status: 'gravada',
    espectadores: 247,
    host: 'Dra. Patrícia Saúde',
    categoria: 'Hidratação',
  },
  {
    id: '5',
    titulo: 'Sono Reparador — A Base da Saúde',
    descricao: 'Como melhorar a qualidade do sono em 7 dias com técnicas simples.',
    data: '2026-07-21',
    hora: '21:00',
    duracao: '1h15',
    link: '#',
    status: 'gravada',
    espectadores: 189,
    host: 'Dr. Marcus Sono',
    categoria: 'Sono',
  },
];

const CATEGORIAS_COR: Record<string, string> = {
  Nutrição: 'bg-amber-900/30 text-amber-400 border-amber-700/30',
  Movimento: 'bg-green-900/30 text-green-400 border-green-700/30',
  Mentalidade: 'bg-pink-900/30 text-pink-400 border-pink-700/30',
  Hidratação: 'bg-blue-900/30 text-blue-400 border-blue-700/30',
  Sono: 'bg-purple-900/30 text-purple-400 border-purple-700/30',
};

export default function LivesPage() {
  const [notificacoesAtivas, setNotificacoesAtivas] = useState<Set<string>>(new Set());

  const toggleNotificacao = (id: string) => {
    setNotificacoesAtivas(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const proximas = LIVES.filter(l => l.status === 'proxima');
  const gravadas = LIVES.filter(l => l.status === 'gravada');
  const aoVivo = LIVES.filter(l => l.status === 'ao_vivo');

  const formatarData = (data: string, hora: string) => {
    const d = new Date(data + 'T' + hora);
    return d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' }) + ' às ' + hora;
  };

  const LiveCard = ({ live }: { live: Live }) => (
    <Card className={`border-border bg-card hover:border-primary/30 transition-colors ${
      live.status === 'ao_vivo' ? 'border-red-500/50 bg-red-950/10' : ''
    }`}>
      <CardContent className="pt-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              {live.status === 'ao_vivo' && (
                <Badge className="bg-red-600 text-white text-xs animate-pulse">● AO VIVO</Badge>
              )}
              <Badge className={`text-xs border ${CATEGORIAS_COR[live.categoria] || 'bg-muted text-muted-foreground'}`}>
                {live.categoria}
              </Badge>
            </div>
            <h3 className="font-bold text-foreground leading-tight">{live.titulo}</h3>
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{live.descricao}</p>

            <div className="mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {live.status === 'gravada'
                  ? new Date(live.data + 'T12:00:00').toLocaleDateString('pt-BR')
                  : formatarData(live.data, live.hora)
                }
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" /> {live.duracao}
              </span>
              {live.espectadores && (
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" /> {live.espectadores} assistiram
                </span>
              )}
            </div>
            <p className="text-xs text-primary mt-1 font-medium">👤 {live.host}</p>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            {live.status === 'gravada' ? (
              <Button size="sm" variant="outline" className="text-xs" disabled>
                <Play className="w-3 h-3 mr-1" /> Assistir
              </Button>
            ) : live.status === 'ao_vivo' ? (
              <Button size="sm" className="bg-red-600 hover:bg-red-700 text-xs" onClick={() => window.open(live.link, '_blank')}>
                <Video className="w-3 h-3 mr-1" /> Entrar
              </Button>
            ) : (
              <>
                <Button
                  size="sm"
                  variant={notificacoesAtivas.has(live.id) ? 'default' : 'outline'}
                  className="text-xs"
                  onClick={() => toggleNotificacao(live.id)}
                >
                  <Bell className="w-3 h-3 mr-1" />
                  {notificacoesAtivas.has(live.id) ? 'Inscrito' : 'Lembrar'}
                </Button>
                <Button size="sm" variant="ghost" className="text-xs" onClick={() => window.open(live.link, '_blank')}>
                  <ExternalLink className="w-3 h-3 mr-1" /> Info
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6 animate-in fade-in">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Lives Exclusivas</h2>
        <p className="text-muted-foreground">Conteúdo ao vivo com especialistas em saúde e bem-estar.</p>
      </div>

      {/* Banner próxima live */}
      {proximas.length > 0 && (
        <Card className="border-primary/30 bg-gradient-to-r from-primary/10 to-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-primary/20 p-2 rounded-full">
                <Video className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Próxima Live</p>
                <p className="font-bold text-foreground">{proximas[0].titulo}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-3">{formatarData(proximas[0].data, proximas[0].hora)}</p>
            <Button
              size="sm"
              onClick={() => toggleNotificacao(proximas[0].id)}
              className={notificacoesAtivas.has(proximas[0].id) ? 'bg-green-700 hover:bg-green-600' : 'bg-primary hover:bg-primary/90'}
            >
              <Bell className="w-4 h-4 mr-2" />
              {notificacoesAtivas.has(proximas[0].id) ? '✓ Lembrete ativado!' : 'Ativar lembrete'}
            </Button>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="proximas">
        <TabsList className="w-full">
          <TabsTrigger value="proximas" className="flex-1">
            📅 Próximas ({proximas.length})
          </TabsTrigger>
          <TabsTrigger value="gravadas" className="flex-1">
            🎬 Gravadas ({gravadas.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="proximas">
          <div className="space-y-3">
            {aoVivo.map(live => <LiveCard key={live.id} live={live} />)}
            {proximas.map(live => <LiveCard key={live.id} live={live} />)}
            {proximas.length === 0 && aoVivo.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <Calendar className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Nenhuma live agendada no momento.</p>
                <p className="text-sm mt-1">Fique atento às novidades!</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="gravadas">
          <div className="space-y-3">
            {gravadas.map(live => <LiveCard key={live.id} live={live} />)}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
