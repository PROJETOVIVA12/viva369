import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErro('');
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
      if (error) throw error;
      navigate('/dashboard');
    } catch (err: any) {
      setErro(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo 369 grande */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <svg width="100" height="100" viewBox="0 0 200 200">
              <defs>
                <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ef4444"/>
                  <stop offset="35%" stopColor="#f59e0b"/>
                  <stop offset="70%" stopColor="#fbbf24"/>
                  <stop offset="100%" stopColor="#00A651"/>
                </linearGradient>
              </defs>
              <circle cx="100" cy="100" r="85" fill="none" stroke="url(#grad)" strokeWidth="14"/>
              <text x="100" y="112" fontFamily="Georgia, serif" fontSize="64" fontWeight="bold" fill="url(#grad)" textAnchor="middle">369</text>
            </svg>
          </div>
        </div>

        {/* Título */}
        <h1 className="text-4xl font-bold text-center text-white mb-1" style={{ fontFamily: 'Georgia, serif' }}>
          VIVA369
        </h1>
        <p className="text-center text-green-500 text-sm font-semibold mb-8">Transformação de hábitos</p>

        {/* Formulário */}
        {erro && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 mb-4">
            <p className="text-red-400 text-sm text-center">{erro}</p>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:border-green-500 transition"
              required
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-1">Senha</label>
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:border-green-500 transition"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-green-500 hover:bg-green-400 text-white font-bold py-3 rounded-xl transition text-lg"
          >
            Entrar
          </button>
        </form>

        {/* Links */}
        <div className="mt-6 text-center">
          <p className="text-zinc-500 text-sm">
            Não tem conta?{' '}
            <a href="/registrar" className="text-green-500 hover:underline font-medium">
              Cadastre-se
            </a>
          </p>
          <p className="text-zinc-600 text-xs mt-4 border-t border-zinc-800 pt-4">
            Teste: <span className="text-green-400">admin@milagourmet.com</span> / <span className="text-green-400">Mila123456!</span>
          </p>
        </div>
      </div>
    </div>
  );
}
