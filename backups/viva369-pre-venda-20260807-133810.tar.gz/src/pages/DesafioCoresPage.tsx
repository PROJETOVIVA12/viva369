import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import {
  Calendar, CheckCircle, Circle, Clock, Flame,
  Leaf, Apple, Droplet, Moon, Sun, Zap,
  Award, Crown, Gem, Sparkles, Target,
  Users, Share2, Lock, Unlock, Star,
  Camera, Send, Image, Upload
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { cn } from '@/lib/utils';

// ============================================
// ESTRUTURA DO DESAFIO DAS CORES
// ============================================

const DESAFIO_CORES = {
  verde: {
    nome: 'DESAFIO VERDE',
    cor: 'from-green-500 to-emerald-500',
    bg: 'bg-green-500/10',
    border: 'border-green-500/30',
    text: 'text-green-400',
    icone: Leaf,
    emoji: '🌿',
    duracao: '7 dias',
    descricao: 'Fase de desintoxicação e limpeza profunda',
    beneficios: 'Eliminação de toxinas, redução de inchaço, pele mais clara'
  },
  vermelho: {
    nome: 'DESAFIO VERMELHO',
    cor: 'from-red-500 to-rose-500',
    bg: 'bg-red-500/10',
    border: 'border-red-500/30',
    text: 'text-red-400',
    icone: Flame,
    emoji: '🔥',
    duracao: '7 dias',
    descricao: 'Fase de aceleração do metabolismo',
    beneficios: 'Queima de gordura, aumento de energia, foco mental'
  },
  amarelo: {
    nome: 'DESAFIO AMARELO',
    cor: 'from-yellow-500 to-amber-500',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/30',
    text: 'text-yellow-400',
    icone: Sun,
    emoji: '☀️',
    duracao: '7 dias',
    descricao: 'Fase de fortalecimento e tonificação',
    beneficios: 'Aumento de massa muscular, definição corporal, vitalidade'
  },
  roxo: {
    nome: 'DESAFIO ROXO',
    cor: 'from-purple-500 to-violet-500',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/30',
    text: 'text-purple-400',
    icone: Sparkles,
    emoji: '💜',
    duracao: '9 dias',
    descricao: 'Fase de consolidação e manutenção',
    beneficios: 'Hábitos consolidados, resultados permanentes, nova identidade'
  }
};

// ============================================
// GRUPOS WHATSAPP
// ============================================

const GRUPOS_WHATSAPP = [
  {
    id: 1,
    nome: 'Desafio Individual VIVA369',
    descricao: 'Grupo para quem está se desafiando a si mesmo',
    link: 'https://chat.whatsapp.com/ChwcUvruAfR5D26a7T6hjg',
    tipo: 'individual'
  },
  {
    id: 2,
    nome: 'Desafio com Amigos',
    descricao: 'Desafie seus amigos e compartilhe resultados',
    link: 'https://chat.whatsapp.com/IsG3fYmUUqr33no68CEnBI',
    tipo: 'amigos'
  },
  {
    id: 3,
    nome: 'Desafio em Grupo',
    descricao: 'Grupos desafiando outros grupos',
    link: 'https://chat.whatsapp.com/KrPQjNdugLZ3XTEKw5rqiv',
    tipo: 'grupo'
  }
];

export default function DesafioCoresPage() {
  const { user } = useAuth();
  const [diasCompletos, setDiasCompletos] = useState(0);
  const [desafioAtivo, setDesafioAtivo] = useState(false);
  const [selectedColor, setSelectedColor] = useState('verde');
  const [showDialog, setShowDialog] = useState(false);
  const [dialogType, setDialogType] = useState('');
  const [fotoComprovante, setFotoComprovante] = useState<File | null>(null);
  const [mensagemGrupo, setMensagemGrupo] = useState('');
  const [grupoSelecionado, setGrupoSelecionado] = useState('');
  const [desafioConcluido, setDesafioConcluido] = useState(false);

  // Carregar progresso do Supabase
  useEffect(() => {
    if (user) {
      carregarProgresso();
    }
  }, [user]);

  const carregarProgresso = async () => {
    try {
      const { data, error } = await supabase
        .from('desafio_cores')
        .select('*')
        .eq('usuario_id', user?.id)
        .single();

      if (data) {
        setDiasCompletos(data.dias_completos || 0);
        setDesafioAtivo(data.ativo || false);
      }
    } catch (error) {
      console.error('Erro ao carregar progresso:', error);
    }
  };

  const salvarProgresso = async () => {
    try {
      await supabase
        .from('desafio_cores')
        .upsert({
          usuario_id: user?.id,
          dias_completos: diasCompletos,
          ativo: desafioAtivo,
          ultima_atualizacao: new Date().toISOString()
        });
    } catch (error) {
      console.error('Erro ao salvar progresso:', error);
    }
  };

  const iniciarDesafio = async () => {
    setDesafioAtivo(true);
    setDiasCompletos(0);
    await salvarProgresso();
  };

  const marcarDia = async () => {
    if (diasCompletos < 30 && desafioAtivo) {
      const novoDias = diasCompletos + 1;
      setDiasCompletos(novoDias);
      await salvarProgresso();
      
      if (novoDias === 30) {
        setDesafioConcluido(true);
      }
    }
  };

  const handleFotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFotoComprovante(e.target.files[0]);
    }
  };

  const enviarComprovante = async () => {
    if (!fotoComprovante) {
      alert('Por favor, selecione uma foto de comprovação');
      return;
    }

    try {
      // Upload da foto para o Supabase Storage
      const fileExt = fotoComprovante.name.split('.').pop();
      const fileName = `${user?.id}_${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('desafios')
        .upload(fileName, fotoComprovante);

      if (uploadError) throw uploadError;

      // Salvar registro do dia completo
      await supabase
        .from('desafio_dias')
        .insert({
          usuario_id: user?.id,
          dia: diasCompletos + 1,
          foto_url: fileName,
          data_comprovacao: new Date().toISOString()
        });

      alert('✅ Comprovante enviado com sucesso!');
      setShowDialog(false);
      setFotoComprovante(null);
      
      // Marcar o dia como completo
      await marcarDia();
    } catch (error) {
      console.error('Erro ao enviar comprovante:', error);
      alert('Erro ao enviar comprovante. Tente novamente.');
    }
  };

  const desafiarAmigo = () => {
    setDialogType('amigo');
    setShowDialog(true);
  };

  const desafiarGrupo = () => {
    setDialogType('grupo');
    setShowDialog(true);
  };

  const enviarConvite = async () => {
    try {
      const linkConvite = `https://viva-plus--viva369official.replit.app/registrar?ref=${user?.id}`;
      
      if (dialogType === 'amigo') {
        const mensagem = `🚀 *Desafio VIVA369 - ${DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES].nome}*\n\n`
          + `Olá! Estou te desafiando a participar do Desafio das Cores do VIVA369!\n\n`
          + `🎯 *Desafio:* ${DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES].nome}\n`
          + `📅 *Duração:* ${DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES].duracao}\n`
          + `💚 *Benefícios:* ${DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES].beneficios}\n\n`
          + `🔗 *Link para participar:* ${linkConvite}\n\n`
          + `Vamos juntos nessa jornada de transformação! 💪`;
        
        // Abrir WhatsApp com mensagem
        window.open(`https://wa.me/?text=${encodeURIComponent(mensagem)}`, '_blank');
      } else if (dialogType === 'grupo') {
        const mensagem = `🏆 *Desafio em Grupo VIVA369*\n\n`
          + `Nosso grupo está desafiando ${grupoSelecionado || 'outro grupo'}!\n\n`
          + `🎯 *Desafio:* ${DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES].nome}\n`
          + `📅 *Duração:* ${DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES].duracao}\n\n`
          + `🔗 *Entre no grupo:* ${GRUPOS_WHATSAPP.find(g => g.tipo === 'grupo')?.link}\n\n`
          + `Vamos ver quem consegue completar o desafio primeiro! 💪`;
        
        // Abrir WhatsApp com mensagem
        window.open(`https://wa.me/?text=${encodeURIComponent(mensagem)}`, '_blank');
      }
      
      setShowDialog(false);
    } catch (error) {
      console.error('Erro ao enviar convite:', error);
      alert('Erro ao enviar convite. Tente novamente.');
    }
  };

  const progressoTotal = Math.min((diasCompletos / 30) * 100, 100);
  const info = DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES];
  const Icon = info?.icone || Leaf;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-amber-500 p-6">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Sparkles className="h-6 w-6" />
              Desafio das Cores
            </h1>
            <p className="text-white/80 text-sm">30, 60 e 90 dias de transformação</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Badge className="bg-white/20 text-white border-0 px-4 py-2">
              <Target className="h-4 w-4 mr-2" />
              {diasCompletos} / 30 dias
            </Badge>
            <Badge className="bg-white/20 text-white border-0 px-4 py-2">
              {desafioAtivo ? '🔥 Ativo' : '⏸️ Pausado'}
            </Badge>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-sm text-white/70 mb-1">
            <span>Início</span>
            <span>{Math.round(progressoTotal)}%</span>
            <span>Meta</span>
          </div>
          <Progress value={progressoTotal} className="h-2 bg-white/20" />
        </div>
      </div>

      {/* Botões */}
      <div className="flex flex-wrap gap-3">
        {!desafioAtivo ? (
          <Button className="bg-gradient-to-r from-emerald-500 to-amber-500 text-white" onClick={iniciarDesafio}>
            <Unlock className="h-4 w-4 mr-2" />
            Iniciar Desafio
          </Button>
        ) : (
          <Button className="bg-emerald-500 hover:bg-emerald-600 text-white" onClick={() => setShowDialog(true)}>
            <Camera className="h-4 w-4 mr-2" />
            Completar Dia
          </Button>
        )}
        <Button variant="outline" className="border-slate-600 text-slate-400 hover:text-white" onClick={desafiarAmigo}>
          <Share2 className="h-4 w-4 mr-2" />
          Convidar Amigo
        </Button>
        <Button variant="outline" className="border-slate-600 text-slate-400 hover:text-white" onClick={desafiarGrupo}>
          <Users className="h-4 w-4 mr-2" />
          Desafiar Grupo
        </Button>
      </div>

      {/* Calendário */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white text-sm">Sua Jornada</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'].map((dia, idx) => {
              const completo = idx < (diasCompletos % 7);
              return (
                <div key={idx} className="text-center">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center mx-auto text-sm font-medium transition-all",
                    completo ? "bg-emerald-500 text-white" : "bg-slate-700 text-slate-400"
                  )}>
                    {completo ? <CheckCircle className="h-5 w-5" /> : dia.substring(0, 1)}
                  </div>
                  <span className="text-[10px] text-slate-500">{dia}</span>
                </div>
              );
            })}
          </div>
          <p className="text-xs text-slate-500 mt-4 text-center">
            {diasCompletos >= 7 ? '✅ Semana 1 concluída!' : 'Complete 7 dias para avançar'}
          </p>
        </CardContent>
      </Card>

      {/* Cores */}
      <Tabs defaultValue="verde" className="w-full" onValueChange={setSelectedColor}>
        <TabsList className="grid grid-cols-4 bg-slate-800 p-1 rounded-xl">
          {Object.keys(DESAFIO_CORES).map((cor) => {
            const c = DESAFIO_CORES[cor as keyof typeof DESAFIO_CORES];
            return (
              <TabsTrigger key={cor} value={cor} className={cn("data-[state=active]:bg-opacity-20 data-[state=active]:text-white", c.bg)}>
                <span className="mr-2">{c.emoji}</span>
                {cor.charAt(0).toUpperCase() + cor.slice(1)}
              </TabsTrigger>
            );
          })}
        </TabsList>

        {Object.keys(DESAFIO_CORES).map((cor) => {
          const c = DESAFIO_CORES[cor as keyof typeof DESAFIO_CORES];
          const IconC = c.icone;
          return (
            <TabsContent key={cor} value={cor} className="mt-6">
              <Card className={cn("border-2", c.border, c.bg)}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={cn("p-3 rounded-xl bg-gradient-to-r", c.cor, "text-white")}>
                      <IconC className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className={cn("text-xl", c.text)}>{c.nome}</CardTitle>
                      <CardDescription className="text-slate-400">{c.descricao}</CardDescription>
                    </div>
                    <Badge className={cn("ml-auto", c.border, c.text)}>
                      {c.duracao}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-400">{c.beneficios}</p>
                </CardContent>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>

      {/* Grupos WhatsApp */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-emerald-400" />
            Grupos WhatsApp VIVA369
          </CardTitle>
          <CardDescription className="text-slate-400">
            Entre nos grupos para compartilhar sua jornada
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {GRUPOS_WHATSAPP.map((grupo) => (
            <div key={grupo.id} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg hover:bg-slate-700 transition-colors">
              <div>
                <p className="text-white font-medium">{grupo.nome}</p>
                <p className="text-xs text-slate-400">{grupo.descricao}</p>
              </div>
              <Button 
                variant="outline" 
                className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20"
                onClick={() => window.open(grupo.link, '_blank')}
              >
                <Send className="h-4 w-4 mr-2" />
                Entrar
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Dialog - Completar Dia */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Camera className="h-5 w-5 text-emerald-400" />
              {dialogType === 'amigo' ? 'Desafiar Amigo' : 
               dialogType === 'grupo' ? 'Desafiar Grupo' : 
               'Completar Dia do Desafio'}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              {dialogType === 'amigo' ? 'Compartilhe o desafio com seu amigo' :
               dialogType === 'grupo' ? 'Desafie outro grupo no WhatsApp' :
               'Envie uma foto comprovando que completou o dia'}
            </DialogDescription>
          </DialogHeader>

          {dialogType === 'amigo' || dialogType === 'grupo' ? (
            <div className="space-y-4">
              <div className="bg-slate-700/30 p-4 rounded-lg">
                <p className="text-sm text-slate-300">
                  {dialogType === 'amigo' ? 
                    'Você está prestes a desafiar um amigo para o Desafio das Cores!' :
                    'Você está prestes a desafiar um grupo para o Desafio das Cores!'}
                </p>
                <div className="mt-3 flex items-center gap-2 text-emerald-400">
                  <Sparkles className="h-4 w-4" />
                  <span className="text-sm">{DESAFIO_CORES[selectedColor as keyof typeof DESAFIO_CORES].nome}</span>
                </div>
              </div>
              {dialogType === 'grupo' && (
                <div>
                  <Label className="text-slate-400">Nome do grupo desafiado</Label>
                  <Input 
                    placeholder="Ex: Grupo das Mulheres"
                    value={grupoSelecionado}
                    onChange={(e) => setGrupoSelecionado(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
              )}
              <Button className="w-full bg-gradient-to-r from-emerald-500 to-amber-500 text-white" onClick={enviarConvite}>
                <Send className="h-4 w-4 mr-2" />
                Enviar Convite
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFotoUpload}
                  className="hidden"
                  id="foto-upload"
                />
                <label htmlFor="foto-upload" className="cursor-pointer">
                  {fotoComprovante ? (
                    <div>
                      <Image className="h-12 w-12 mx-auto text-emerald-400" />
                      <p className="text-sm text-slate-300 mt-2">{fotoComprovante.name}</p>
                    </div>
                  ) : (
                    <div>
                      <Upload className="h-12 w-12 mx-auto text-slate-500" />
                      <p className="text-sm text-slate-400 mt-2">Clique para selecionar uma foto</p>
                      <p className="text-xs text-slate-500">Tire uma foto comprovando sua atividade</p>
                    </div>
                  )}
                </label>
              </div>
              <p className="text-xs text-slate-500 text-center">
                A foto será compartilhada com seu amigo ou grupo como comprovação
              </p>
              <Button 
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
                onClick={enviarComprovante}
                disabled={!fotoComprovante}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Confirmar Dia
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
