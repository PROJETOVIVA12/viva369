import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { LogOut, Home, Users, Gift, Award, Calendar, Flame, Star, Scale } from 'lucide-react';
export default function DashboardPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    streak: 0,
    pontos: 0,
    nivel: 1,
    diasJornada: 0,
    desafio: 'Complete o desafio de hoje para ganhar pontos!'
  });
  const navigate = useNavigate();
  useEffect(() => {
    carregarDados();
  }, []);
  const carregarDados = async () => {
    setLoading(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      setUser(userData.user);
      const { data: perfil } = await supabase
        .from('perfis')
        .select('*')
        .eq('id', userData.user?.id)
        .single();
      if (perfil) {
        setStats({
          streak: perfil.streak_dias || 0,
          pontos: perfil.pontuacao_viva || 0,
          nivel: perfil.nivel_saude || 1,
          diasJornada: perfil.dias_jornada || 0,
          desafio: 'Complete o desafio de hoje para ganhar pontos!'
        });
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };
  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };
  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-green-500 border-t-transparent mx-auto"></div>
          <p className="mt-4 text-zinc-400">Carregando sua jornada...</p>
        </div>
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-black text-white flex">
      <aside className="w-64 bg-zinc-900/50 border-r border-zinc-800 p-4 min-h-screen">
        <div className="flex items-center gap-2 mb-8">
          <span className="text-2xl">🔥</span>
          <span className="text-xl font-bold text-green-500">VIVA369</span>
        </div>
        <div className="mb-6 px-3 py-2 bg-zinc-800/50 rounded-xl">
          <p className="text-xs text-zinc-400">Bem-vindo,</p>
          <p className="font-bold text-white truncate">{user?.user_metadata?.nome_completo || 'Usuário'}</p>
        </div>
        <nav className="space-y-1">
          <button onClick={() => navigate('/dashboard')} className="w-full flex items-center gap-3 px-3 py-2 bg-green-500/20 text-green-500 rounded-lg text-sm">
            <Home className="w-4 h-4" /> Dashboard
          </button>
          <button onClick={() => navigate('/rede-social')} className="w-full flex items-center gap-3 px-3 py-2 text-zinc-400 hover:bg-zinc-800 rounded-lg text-sm transition">
            <Users className="w-4 h-4" /> Comunidade
          </button>
          <button onClick={() => navigate('/indicacoes')} className="w-full flex items-center gap-3 px-3 py-2 text-zinc-400 hover:bg-zinc-800 rounded-lg text-sm transition">
            <Gift className="w-4 h-4" /> Indicações
          </button>
          <button onClick={() => navigate('/premiacoes')} className="w-full flex items-center gap-3 px-3 py-2 text-zinc-400 hover:bg-zinc-800 rounded-lg text-sm transition">
            <Award className="w-4 h-4" /> Premiações
          </button>
          <button onClick={() => navigate('/saude')} className="w-full flex items-center gap-3 px-3 py-2 text-zinc-400 hover:bg-zinc-800 rounded-lg text-sm transition">
            <Calendar className="w-4 h-4" /> Jornada
          </button>
          <button onClick={() => navigate('/bioimpedancia')} className="w-full flex items-center gap-3 px-3 py-2 text-zinc-400 hover:bg-zinc-800 rounded-lg text-sm transition">
            <Scale className="w-4 h-4" /> Bioimpedância
          </button>
        </nav>
        <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2 mt-8 text-red-400 hover:bg-red-950/50 rounded-lg text-sm transition">
          <LogOut className="w-4 h-4" /> Sair
        </button>
      </aside>
      <main className="flex-1 p-6 overflow-y-auto">
        <h1 className="text-2xl font-bold text-white mb-6">
          👋 Bem-vindo, <span className="text-green-500">{user?.user_metadata?.nome_completo || 'Usuário'}</span>!
        </h1>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-2 text-zinc-400 text-sm">
              <Flame className="w-4 h-4 text-orange-500" />
              Sequência de Dias
            </div>
            <p className="text-2xl font-bold text-white mt-1">{stats.streak}</p>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-2 text-zinc-400 text-sm">
              <Star className="w-4 h-4 text-yellow-500" />
              Pontuação VIVA+
            </div>
            <p className="text-2xl font-bold text-green-500 mt-1">{stats.pontos}</p>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-2 text-zinc-400 text-sm">
              <span className="text-lg">⭐</span>
              Nível de Saúde
            </div>
            <p className="text-2xl font-bold text-white mt-1">{stats.nivel}</p>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-2 text-zinc-400 text-sm">
              <Calendar className="w-4 h-4 text-blue-500" />
              Dias na Jornada
            </div>
            <p className="text-2xl font-bold text-white mt-1">{stats.diasJornada}/90</p>
          </div>
        </div>
        <div className="bg-gradient-to-r from-green-900/20 to-zinc-900 border border-green-500/20 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-2">🎯 Seu Próximo Desafio</h2>
          <p className="text-zinc-400">{stats.desafio}</p>
          <button className="mt-4 bg-green-500 hover:bg-green-400 text-white font-bold px-6 py-2 rounded-xl transition">
            Marcar como feito
          </button>
        </div>
      </main>
    </div>
  );
}
