import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DollarSign, TrendingUp, ShoppingBag } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface DailyStats {
  date: string;
  receita: number;
}

export default function FinancasPage() {
  const [data, setData] = useState<DailyStats[]>([]);
  const [totais, setTotais] = useState({ receita: 0, ticketMedio: 0, pedidos: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchFinancas() {
      const sevenDaysAgo = subDays(new Date(), 6);
      sevenDaysAgo.setHours(0, 0, 0, 0);

      const { data: pedidos } = await supabase
        .from('pedidos')
        .select('total, criado_em, status')
        .gte('criado_em', sevenDaysAgo.toISOString())
        .neq('status', 'cancelado');

      if (pedidos) {
        let totalReceita = 0;
        let totalPedidos = pedidos.length;

        // Group by date
        const grouped: Record<string, number> = {};
        for (let i = 6; i >= 0; i--) {
          const d = subDays(new Date(), i);
          grouped[format(d, 'dd/MM')] = 0;
        }

        pedidos.forEach(p => {
          const val = Number(p.total);
          totalReceita += val;
          const dateKey = format(new Date(p.criado_em), 'dd/MM');
          if (grouped[dateKey] !== undefined) {
            grouped[dateKey] += val;
          }
        });

        const chartData = Object.entries(grouped).map(([date, receita]) => ({ date, receita }));
        setData(chartData);
        setTotais({
          receita: totalReceita,
          ticketMedio: totalPedidos > 0 ? totalReceita / totalPedidos : 0,
          pedidos: totalPedidos
        });
      }
      setLoading(false);
    }
    fetchFinancas();
  }, []);

  return (
    <div className="space-y-6 animate-in fade-in">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Finanças</h2>
        <p className="text-muted-foreground">Visão financeira dos últimos 7 dias.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {totais.receita.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Nos últimos 7 dias</p>
          </CardContent>
        </Card>
        
        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ticket Médio</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {totais.ticketMedio.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Média por pedido</p>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Pedidos</CardTitle>
            <ShoppingBag className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totais.pedidos}</div>
            <p className="text-xs text-muted-foreground">Pedidos finalizados</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle>Evolução da Receita</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">Carregando gráfico...</div>
          ) : (
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                  <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `R$${value}`} />
                  <Tooltip 
                    cursor={{fill: '#1e293b'}}
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc', borderRadius: '8px' }}
                    itemStyle={{ color: '#b45309', fontWeight: 'bold' }}
                    formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Receita']}
                  />
                  <Bar dataKey="receita" fill="#b45309" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
