import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { UserPlus, Loader2, Gift } from 'lucide-react';

const schema = z.object({
  nome: z.string().min(2, { message: 'Nome deve ter ao menos 2 caracteres.' }),
  email: z.string().email({ message: 'E-mail inválido.' }),
  telefone: z.string().optional(),
  password: z.string().min(6, { message: 'Mínimo de 6 caracteres.' }),
  confirmar: z.string(),
}).refine(d => d.password === d.confirmar, {
  message: 'As senhas não coincidem.',
  path: ['confirmar'],
});

export default function CadastroPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [codigoRef, setCodigoRef] = useState<string | null>(null);
  const [nomeIndicador, setNomeIndicador] = useState<string | null>(null);

  // Detecta ?ref=CODIGO na URL
  useEffect(() => {
    const params = searchParams;
    const ref = params.get('ref');
    if (ref) {
      setCodigoRef(ref);
      // Busca nome do líder pelo código
      supabase
        .from('perfis')
        .select('nome')
        .eq('codigo_indicacao', ref)
        .single()
        .then(({ data }) => {
          if (data) setNomeIndicador(data.nome);
        });
    }
  }, [searchParams]);

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: { nome: '', email: '', telefone: '', password: '', confirmar: '' },
  });

  async function onSubmit(values: z.infer<typeof schema>) {
    setLoading(true);
    try {
      // 1. Cria usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: values.email,
        password: values.password,
      });
      if (authError) throw authError;

      const userId = authData.user?.id;
      if (!userId) throw new Error('Erro ao criar usuário.');

      // 2. Busca ID do líder pelo código de referência
      let liderId: string | null = null;
      if (codigoRef) {
        const { data: liderData } = await supabase
          .from('perfis')
          .select('id')
          .eq('codigo_indicacao', codigoRef)
          .single();
        if (liderData) liderId = liderData.id;
      }

      // 3. Cria perfil na tabela perfis
      const { error: perfilError } = await supabase.from('perfis').insert({
        id: userId,
        nome: values.nome,
        email: values.email,
        telefone: values.telefone || null,
        lider_id: liderId,
        role: 'cliente',
      });
      if (perfilError) throw perfilError;

      // 4. Cria pagamento pendente
      await supabase.from('pagamentos').insert({
        usuario_id: userId,
        lider_id: liderId,
        valor: 250.00,
        status: 'pendente',
        metodo: 'ton',
      });

      toast({ title: '✅ Cadastro realizado!', description: 'Redirecionando para o pagamento...' });

      // 5. Redireciona para pagamento TON
      setTimeout(() => {
        window.location.href = 'https://payment-link-v3.ton.com.br/pl_aLlyO8bqA305RdwSDpiLMpNYvJPgjKw7';
      }, 1500);

    } catch (e: any) {
      toast({ title: 'Erro no cadastro', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="bg-primary/20 p-4 rounded-full text-primary mb-4">
            <UserPlus className="w-10 h-10" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">Criar Conta Viva369</h1>
          <p className="text-muted-foreground mt-2">Comece sua jornada de saúde hoje.</p>

          {codigoRef && (
            <div className="mt-3 flex items-center gap-2 px-4 py-2 bg-green-900/30 border border-green-700/50 rounded-lg">
              <Gift className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-300">
                Indicado por: <strong>{nomeIndicador || codigoRef}</strong>
              </span>
              <Badge className="bg-green-700 text-green-100 text-xs">Bônus ativo</Badge>
            </div>
          )}
        </div>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Cadastro</CardTitle>
            <CardDescription>
              Preencha seus dados. Após o cadastro, você será direcionado ao pagamento de <strong className="text-primary">R$ 250,00</strong>.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField control={form.control} name="nome" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome Completo</FormLabel>
                    <FormControl><Input placeholder="Seu nome" {...field} className="bg-background border-border" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel>E-mail</FormLabel>
                    <FormControl><Input type="email" placeholder="seu@email.com" {...field} className="bg-background border-border" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="telefone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>WhatsApp <span className="text-muted-foreground text-xs">(opcional)</span></FormLabel>
                    <FormControl><Input placeholder="(71) 99999-9999" {...field} className="bg-background border-border" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="password" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Senha</FormLabel>
                    <FormControl><Input type="password" placeholder="Mínimo 6 caracteres" {...field} className="bg-background border-border" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="confirmar" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirmar Senha</FormLabel>
                    <FormControl><Input type="password" placeholder="Repita a senha" {...field} className="bg-background border-border" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90 font-bold" disabled={loading}>
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Cadastrar e Ir para Pagamento →
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-muted-foreground">
              Já tem conta?{' '}
              <Link to="/login" className="text-primary hover:underline font-medium">Faça login</Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
